<?php 
$tabela = 'usuarios';
require_once("../../../conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nivel = $_POST['nivel'];
$endereco = $_POST['endereco'];
$senha = '123';
$senha_crip = password_hash($senha, PASSWORD_DEFAULT);
$chave_pix = $_POST['chave_pix'];
$id = $_POST['id'];

$email = strtolower($email);

//validacao email
$query = $pdo->query("SELECT * from $tabela where email = '$email'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$id_reg = @$res[0]['id'];
if(@count($res) > 0 and $id != $id_reg){
	echo 'Email já Cadastrado!';
	exit();
}

//validacao telefone
$query = $pdo->query("SELECT * from $tabela where telefone = '$telefone'");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$id_reg = @$res[0]['id'];
if(@count($res) > 0 and $id != $id_reg){
	echo 'Telefone já Cadastrado!';
	exit();
}

if($id == ""){
$query = $pdo->prepare("INSERT INTO $tabela SET nome = :nome, email = :email, senha = '$senha', senha_crip = '$senha_crip', nivel = '$nivel', ativo = 'Sim', foto = 'sem-foto.jpg', telefone = :telefone, data = curDate(), endereco = :endereco, chave_pix = :chave_pix ");
	
}else{
$query = $pdo->prepare("UPDATE $tabela SET nome = :nome, email = :email, nivel = '$nivel', telefone = :telefone, endereco = :endereco, chave_pix = :chave_pix where id = '$id'");
}
$query->bindValue(":nome", "$nome");
$query->bindValue(":email", "$email");
$query->bindValue(":telefone", "$telefone");
$query->bindValue(":endereco", "$endereco");
$query->bindValue(":chave_pix", "$chave_pix");
$query->execute();

echo 'Salvo com Sucesso';

//api whats
if($api_whatsapp == 'Sim' and $id == ""){
	$telefone_envio = '55'.preg_replace('/[ ()-]+/' , '' , $telefone);
	
	$mensagem .= '🪪 Nome: *' . $nome . '* %0A';
	$mensagem .= '📧 Email: *' . $email . '* %0A';
	$mensagem .= '🔑 Senha: *' . $senha . '* %0A%0A';
	$mensagem .= '_Após acessar o sistema, troque a senha para uma de sua preferência, é importante que esta senha possua um caractere especial, uma letra maiúscula e um numero!_ %0A%0A';
	$mensagem .= '📌 Acesso ao Sistema: *' . $url_sistema . '* %0A%0A';

	require('../../../apis/api_texto.php');
}	
 ?>
